import numpy as np
import matplotlib.pyplot as plt

# Definimos variables
c = 1.0
m = 2.5
g = 9.81

# Condicion inicial
v0 = 0.0

# Definir el vector de tiempos
t = np.linspace(0.0, 10.0, 100)

# Evaluar la solucion
v = v0*np.exp(-c/m*t) + g*m/c*(1 - np.exp(-c/m*t))

plt.plot(t,v)
plt.show()
print(v)