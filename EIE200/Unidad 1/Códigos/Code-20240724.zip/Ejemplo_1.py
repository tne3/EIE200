import numpy as np               # importo libreria de algebra lineal
import matplotlib.pyplot as plt  # import libreria para graficos

a = 1
b = 1.0
c = a + b
print(type(a),type(b),type(c))

lista = [1,2,3,4.0,'hola',[1,2]]
print(lista)

a_arr = np.array([1.0, 2, 3.5])
b_arr = np.array([1.0, 3.1, 4.0]).reshape((3,1))
c_arr = a_arr + b_arr
print(a_arr.shape)
print(b_arr.shape)

A = np.array([[1,2,3],
              [4,5,6],
              [7,8,9]])
AT = A.transpose()
invA = np.invert(A)
print(A.shape)
print(A@b_arr)

zeros = np.zeros([3,2])
ones = np.ones([3,2])
zeros_l = np.zeros_like(A)
ones_l = np.ones_like(A)
print(zeros)
print(ones)

string_1 = 'Hola, '
string_2 = 'mi nombre es '
string_3 = '{:s}'.format('Hernan')
string_4 = ' y mi edad es {:d} años'.format(31)
string_5 = string_1+string_2+string_3+string_4
print(string_5)

lins = np.linspace(1, 10, 10)
aran = np.arange(1, 10, 0.5)
print(lins)
print(aran)