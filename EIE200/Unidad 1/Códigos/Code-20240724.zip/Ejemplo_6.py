def factorial(n):
  if type(n) is int:
    if n == 0:
      fact = 1.0
    else:
      fact = 1.0
      for i in range(1,n+1):
        fact = fact*i
  else:
    fact = None
    print('No se puede calcular el factorial de un numero no-entero')
  return fact


def factorial_while(n):
  if type(n) is int:
    if n == 0:
      fact = 1.0
    else:
      fact = 1.0
      i = 1.0
      while i <= n:
        fact *= i
        i += 1
  else:
    fact = None
    print('No se puede calcular el factorial de un numero no-entero')
  return fact

print(factorial_while(3))