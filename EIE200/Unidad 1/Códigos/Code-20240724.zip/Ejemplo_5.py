def verificador(edad):
  if edad <= 18:
    print('La persona es menor de edad')
  elif edad >= 60.0:
    print('La persona es adulto mayor')
  else:
    print('La persona es mayor de edad')
  return True

foo = verificador(1)
verificador(18.1)
verificador(60.01)
