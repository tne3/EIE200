import numpy as np

def Euler(x_range, h, dydx, y0):
  '''
    ...
  '''
  # Definimos el intervalo de integración
  x_min = x_range[0]
  x_max = x_range[1]
  x = np.arange(x_min, x_max + h, h)

  # Definimos el vector que almacenará la solución
  y = np.zeros_like(x) # np.zeros(x.shape)

  # Aplicamos la condición inicial
  y[0] = y0

  # Resolvemos la EDO usando el método de Euler
  for i in range(x.shape[0]-1):
    k1 = dydx(x[i], y[i])
    y[i+1] = y[i] + k1*h

  return x, y

