import numpy as np
import matplotlib.pyplot as plt
from src.RKMethods import Euler

# Funcion que representa nuestra ecuacion diferencial
#   dy/dx = f(x,y)
def dydx(x, y):
  return -2*x**3 + 12*x**2 - 20*x + 8.5

# Solucion exacta
def y_exact(x):
  return -0.5*x**4 + 4*x**3 - 10*x**2 + 8.5*x + 1.0

# Definimos el paso h
h = 0.5

# Condición inicial y(t=0.0) = 1
y0 = 1.0

# Resolvemos la EDO
x_range = [0.0, 4.0]
x, y = Euler(x_range, h, dydx, y0)

# Definimos la solucion de referencia
y_ref = y_exact(x)

plt.plot(x, y)
plt.plot(x, y_ref)
plt.legend(['Euler', 'Referencia'])
plt.show()
