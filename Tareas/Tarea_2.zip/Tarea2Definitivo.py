import numpy as np #*Libreria para algebra lineal
import matplotlib.pyplot as plt #*Libreria para graficar

'''
#*Pregunta 1:
Se pide resolver el problema con x entre 0 y 1, un paso h = 0.25 y una
condicion inicial y(0) = 1. Se solicita que mostrar los resultados en
un gráfico.
la función es:
F(x, y) = sqrt(y)*((1)/(1 + 2*x))**-1
''' 

#Se define la función:
def Fun(x, y):
    '''
    Esta función ingresa los parametros x e y y retorna la expresión:
    F(x, y) = sqrt(y)*((1)/(1 + 2*x))**-1
    '''
    a = np.sqrt(y)
    b = (1 / (1 + 2*x))**-1
    return a*b
'''
Para responder las preguntas se crean las funciones de Euler, Ralston y
Rungue-Kutta de orden 4 (RK4)
'''

#Función Metodo de Euler:
def Euler(Fun, X, y, h, Y0):
    '''
    Esta funcion trabaja con el metodo de Euler, tal que:
    #* Fun = Función a evaluar
    #* X = Valores de x, como vector
    #* y = Valores de y, como vector 
    #* h = Salto h 
    #* Y0 = Condición inicial
    '''
    YAnswers = np.zeros_like(X) #*Se crea un vector donde poner los resultados
    YAnswers[0] = Y0 #*Se almacena la condicion inicial como el primer elemento del vector
    
    '''
    Mediante un ciclo for se itera la cantidad de elementos que tiene X
    de modo que crear las soluciones.
    Para evitar errores no se crea la última solucion, ya que esta sale 
    del tamaño del vector
    '''
    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers[i])
            YAnswers[i + 1] = YAnswers[i] + (k1*h)
        
    plt.plot(X,YAnswers,label= 'Euler')

    return YAnswers

#Función metodo de Ralston:
def Ralston(Fun, X, y, h, Y0):
    '''
    Esta funcion trabaja con el metodo de Euler, tal que:
    #* Fun = Función a evaluar
    #* x = Valores de x, como vector
    #* y = Valores de y, como vector 
    #* h = Salto h 
    #* Y0 = Condición inicial
    '''
    YAnswers = np.zeros_like(X) #*Se crea un vector donde poner los resultados
    YAnswers[0] = Y0 #*Se almacena la condicion inicial como el primer elemento del vector
    
    '''
    Mediante un ciclo for se itera la cantidad de elementos que tiene X
    de modo que crear las soluciones.
    Para evitar errores no se crea la última solucion, ya que esta sale 
    del tamaño del vector
    '''
    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers[i])
            k2 = Fun((x + (3/4)*h),(YAnswers[i] + (3/4)*k1*h))
            YAnswers[i + 1] = YAnswers[i] + ((1/3)*k1 + (2/3)*k2)*h
    
    plt.plot(X,YAnswers,label= 'Ralston')
    
    return YAnswers

#Función metodo de RK4:
def RK4(Fun, X, y, h, Y0):
    '''
    Esta funcion trabaja con el metodo de Euler, tal que:
    #* Fun = Función a evaluar
    #* x = Valores de x, como vector
    #* y = Valores de y, como vector 
    #* h = Salto h 
    #* Y0 = Condición inicial
    '''
    YAnswers = np.zeros_like(X) #*Se crea un vector donde poner los resultados
    YAnswers[0] = Y0 #*Se almacena la condicion inicial como el primer elemento del vector
    
    '''
    Mediante un ciclo for se itera la cantidad de elementos que tiene X
    de modo que crear las soluciones.
    Para evitar errores no se crea la última solucion, ya que esta sale 
    del tamaño del vector
    '''
    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers[i])
            k2 = Fun((x + (1/2)*h),(YAnswers[i] + (1/2)*k1*h))
            k3 = Fun((x + (1/2)*h),(YAnswers[i] + (1/2)*k2*h))
            k4 = Fun((x + h),(YAnswers[i] + k3*h))
            YAnswers[i + 1] = YAnswers[i] + (1/6)*(k1 + 2*k2 + 2*k3 + k4)*h
    
    plt.plot(X,YAnswers,label= 'RK4')
    
    return YAnswers

#Se define el paso h:
h = 0.25

#Se definen los valores de x a trabajar:
X = np.arange(0.0, 1 + h, h)

#Se define la condición inicial:
YAnswer = np.arange(0.0, 1.0 + h, h)
Y0 = 1 #*Cuando x = 0
YAnswer[0] = Y0

#Mediante las funciones se responden las preguntas 1, 2 y 3:

Euler(Fun, X, YAnswer, h, Y0)
Ralston(Fun, X, YAnswer, h, Y0)
RK4(Fun, X, YAnswer, h, Y0)

plt.title('Resultados de la ED por cada metodo')
plt.xlabel('Valores de x')
plt.ylabel('Valores estimados de y')
plt.legend()
plt.show()


'''
#*Pregunta 2:
Se propone la ED de modelo logístico: 
dp/dt = Kgm*(1-(P/Pmax))*p

Con kgm como el crecimiento bajo condiciones ilimitadas, P la población y
Pmax la población máxima.

La solución analítica es:
P = P0*(Pmax/(P0+(Pmax-P0)*np.exp(-Kgm*t)))

Si en el 1950 había 2555 millones de personas, Kgm = 0.0261 por año y
Pmax = 12000 millones de personas 
'''

'''
#*Pregunta 2,a:
Utilizando RK5 para resolver la ED entre 1950 y 2050 usando h = 5 años,
grafique el resultado
'''

#Se define el modelo logístico:
def ModeloLogistico(t, P):
    '''
    Esta función expresa el crecimiento de una población con la ecuación
    diferencial logística,tal que:
    #*t = tiempo, en este caso que tantos años se evalua la función
    #*P = Población respesto a un tiempo t
    #*Pmax = Población máxima 
    #*Kgm = Tasa de crecimiento bajo condiciones ilimitadas
    En este caso podemos considerar solo dos valores que serán t y p
    '''
    #Se define la Tasa de crecimiento:
    Kgm = 0.0261

    #Se define la población máxima:
    Pmax = 12000
    return Kgm*(1-(P/Pmax))*P

#Se define la condición inicial:
P0 = 2555 #*P(1950) = 2555 [millones]

#Se define un paso h:
h = 5 #*[Años]

#Se define el metodo de Runge-Kutta de orden 5:
def RK5(Fun, X, h, Y0):
    '''
    Esta función trabaja con el metodo RK5, tal que:
    #* Fun = Función a evaluar
    #* x = Valores de x, como vector
    #* y = Valores de y, como vector 
    #* h = Salto h 
    #* Y0 = Condición inicial
    '''
    YAnswers = np.zeros_like(X)
    YAnswers[0] = Y0

    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers[i])
            k2 = Fun((x + (1/4)*h),(YAnswers[i] + (1/4)*k1*h))
            k3 = Fun((x+ (1/4)*h),(YAnswers[i] + (1/8)*k1*h + (1/8)*k2*h))
            k4 = Fun((x + (1/2)*h),(YAnswers[i] - (1/2)*k1*h + k3*h))
            k5 = Fun((x + (3/4)*h),(YAnswers[i] + (3/16)*k1*h + (9/16)*k4*h))
            k6 = Fun((x + h),(YAnswer[i] - (3/7)*k1*h + (2/7)*k2*h + (12/7)*k3*h - (12/7)*k4*h + (8/7)*k5*h))
            YAnswers[i + 1] = YAnswers[i] + (1/90)*(7*k1 + 32*k3 + 12*k4 +32*k5 + 7*k6)*h
    
    plt.plot(X,YAnswers,label= 'RK5')
    return YAnswers

'''
En este caso es útil mencionar que aunque en la función no aparece el 
parámetro t este es necesario para ver cuantas veces tenemos que iterar
para así encontrar los valores de p a lo largo de los años
'''

#Se define el vecto de iteraciones t:
t = np.arange(0, 20 + h, h)

#Con la función 'RK5' evaluamos:
RespuestasEstimadas = RK5(ModeloLogistico, t, h, P0)

'''
#*Pregunta 2,b:
Calcular el error relativo que comete RK5 para cada tiempo t, comparado con
la solución analítica, incluir una tabla con los errores
'''
#Se define la solción del modelo logístico:
def SolucionModeloLogistico(P0, Pmax, Kgm, t):
    '''
    Esta función expresa la solución analítica del modelo logístico para
    este caso particular, de modo que:
    #* P0 = Población inicial
    #* Pmax = Población máxima
    #* Kgm = Tasa de crecimiento bajo condiciones ilimitadas
    #* t = Tiempo
    '''
    #Se define el vector de soluciones:
    PAnswer = np.zeros_like(t)
    PAnswer[0] = P0

    #Se obtiene la población por año:
    for i, T in enumerate(t):
        if i+1 == len(t):
            break
        else:
            PAnswer[i+1] = P0*((Pmax)/(P0+(Pmax-P0)*np.exp(-Kgm*T)))

    #Graficamos los resultados:
    plt.plot(t, PAnswer, label='Solución')

    return PAnswer

#Se define la Tasa de crecimiento:
Kgm = 0.0261

#Se define la población máxima:
Pmax = 12000

#Se define la función de error relativo para calcular los errores por valor:
def ErrorRelativo(RespuestasEstimadas, RespuestasReales):
    '''
    Esta función crea una tabla en formato .txt con las respuestas estimadas, las
    respuestas reales y el error relativo entre ambos, este esta calculado 
    como:
    Error relativo = abs((RespuestasEstimadas - RespuestasReales)/RespuestasReales)
    el orden de la tabla es por filas, de modo que el orden es:
    #*Respuestas estimadas
    #*Respuestas reales
    #*Error relativo
    '''
    AnswersMatriz = []
    AnswersMatriz.append(RespuestasEstimadas)
    AnswersMatriz.append(RespuestasReales)
    ErrorRelativo = []

    for i, RE in enumerate(RespuestasEstimadas):
        ErroresRelativos = abs((RE - RespuestasReales[i])/RespuestasReales[i])
        ErrorRelativo.append(ErroresRelativos)

    AnswersMatriz.append(ErrorRelativo)
    np.transpose(AnswersMatriz)
    np.savetxt('matriz_respuestas1.txt', AnswersMatriz, fmt='%f', delimiter='\t')

    return 

RespuestasReales = SolucionModeloLogistico(P0, Pmax, Kgm, t)
ErrorRelativo(RespuestasEstimadas, RespuestasReales)
plt.legend()
plt.title('Población a lo largo de los años')
plt.xlabel('Años pasados desde 1950')
plt.ylabel('Población estimada')
plt.show()


'''
#*Pregunta 3:
Se solicita ocupar un metodo de RK2 propio para resolver la EDO:
dy(t)/dt = 4*np.exp(0.8*t) - 0.5y(t)

cuya solución es:
y = (4/1.3)*(np.exp(0.8*t) - np.exp(-0.5*t)) + 2*np.exp(-0.5*t)
'''

'''
#*Pregunta 3,a:
Debe resolver la EDO considerando y(0) = 2  y  h = 0.5  en el 
intervalo [0,4]
'''

#Se define el metodo propio de RK2 y las pruebas:
def RK2propio0(Fun, X, y, h, Y0):
    '''
    Esta funcion ocupa el metodo propio de Runge-Kutta de orden 2, este
    no es es igual de eficiente que otros metodos como Ralston o Heun.
    Los parametros de la función son:
    #* Fun = Función a evaluar
    #* X = Vector x a evaluar
    #* y = Vector y de referencia, no es estrictamente necesario 
    #* h = Salto h
    #* Y0 = Condición inicial de la función
    En este caso se cambian los valores a_1 = (1/4) y a_2 = (4/5), 
    además de p_i = q_iJ = (5/8)
    '''
    YAnswers1 = np.zeros_like(X)
    YAnswers1[0] = Y0

    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers1[i])
            k2 = Fun((x + (5/8)*h), (YAnswers1[i] + (5/8)*k1*h))
            YAnswers1[i + 1] = YAnswers1[i] + ((1/4)*k1 + (4/5)*k2)*h
    
    plt.plot(X,YAnswers1,label= 'Prueba 1: a1 = 1/4 a2 = 4/5')
    
    return YAnswers1

def RK2propio1(Fun, X, y, h, Y0):
    '''
    Esta funcion ocupa el metodo propio de Runge-Kutta de orden 2, este
    no es es igual de eficiente que otros metodos como Ralston o Heun.
    Los parametros de la función son:
    #* Fun = Función a evaluar
    #* X = Vector x a evaluar
    #* y = Vector y de referencia, no es estrictamente necesario 
    #* h = Salto h
    #* Y0 = Condición inicial de la función
    En este caso se cambian los valores a_1 = (1/4) y a_2 = (4/5), 
    además de p_i = q_iJ = (5/8)
    '''
    YAnswers1 = np.zeros_like(X)
    YAnswers1[0] = Y0

    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers1[i])
            k2 = Fun((x + (6/7)*h), (YAnswers1[i] + (6/7)*k1*h))
            YAnswers1[i + 1] = YAnswers1[i] + ((1/2)*k1 + (7/12)*k2)*h
    
    plt.plot(X,YAnswers1,label= 'Prueba 2: a1 = 1/2 a2 = 7/12')
    
    return YAnswers1

def RK2propio2(Fun, X, y, h, Y0):
    '''
    Esta funcion ocupa el metodo propio de Runge-Kutta de orden 2, este
    no es es igual de eficiente que otros metodos como Ralston o Heun.
    Los parametros de la función son:
    #* Fun = Función a evaluar
    #* X = Vector x a evaluar
    #* y = Vector y de referencia, no es estrictamente necesario 
    #* h = Salto h
    #* Y0 = Condición inicial de la función
    En este caso se cambian los valores a_1 = (1/4) y a_2 = (4/5), 
    además de p_i = q_iJ = (5/8)
    '''
    YAnswers1 = np.zeros_like(X)
    YAnswers1[0] = Y0

    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers1[i])
            k2 = Fun((x + (2)*h), (YAnswers1[i] + (2)*k1*h))
            YAnswers1[i + 1] = YAnswers1[i] + ((3/4)*k1 + (1/4)*k2)*h
    
    plt.plot(X,YAnswers1,label= 'Prueba 3: a1 = 3/4 a2 = 1/4')
    
    return YAnswers1

def RK2propio3(Fun, X, y, h, Y0):
    '''
    Esta funcion ocupa el metodo propio de Runge-Kutta de orden 2, este
    no es es igual de eficiente que otros metodos como Ralston o Heun.
    Los parametros de la función son:
    #* Fun = Función a evaluar
    #* X = Vector x a evaluar
    #* y = Vector y de referencia, no es estrictamente necesario 
    #* h = Salto h
    #* Y0 = Condición inicial de la función
    En este caso se cambian los valores a_1 = (1/4) y a_2 = (4/5), 
    además de p_i = q_iJ = (5/8)
    '''
    YAnswers1 = np.zeros_like(X)
    YAnswers1[0] = Y0

    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers1[i])
            k2 = Fun((x + (3/2)*h), (YAnswers1[i] + (3/2)*k1*h))
            YAnswers1[i + 1] = YAnswers1[i] + ((1/2)*k1 + (1/3)*k2)*h
    
    plt.plot(X,YAnswers1,label= 'Prueba 4: a1 = 1/2 a2 = 1/3')
    
    return YAnswers1

#Se define la ecuación diferencial:
def Funcion(t, y):
    '''
    Esta funcion describe la EDO de la pregunta en cuestión
    '''

    return 4*np.exp(0.8*t) - 0.5* y

#Se define la condición inicial:
Y0 = 2

#Se define el salto h:
h = 0.5

#Se define el intervalo de iteración:
t =  np.arange(0, 4 + h, h)

YAnswers = np.zeros_like(X)
YAnswers[0] = Y0

#Con la función propia de RK2 evaluamos:
RespuestasEstimadas0 = RK2propio0(Funcion, t, YAnswer, h, Y0)
RespuestasEstimadas1 = RK2propio1(Funcion, t, YAnswer, h, Y0)
RespuestasEstimadas2 = RK2propio2(Funcion, t, YAnswer, h, Y0)
RespuestasEstimadas3 = RK2propio3(Funcion, t, YAnswer, h, Y0)

#print(f'las respuestas estimadas son: {RespuestasEstimadas}')

'''
#*Pregunta 3,b:
El metodo creado debe ser mejor  que el método de Heun, en términos de
error relativos
'''
#Se define el metodo de Heun:
def Heun(Fun, X, h, Y0):
    '''
    Esta funcion trabaja con el metodo de Euler, tal que:
    #* Fun = Función a evaluar
    #* x = Valores de x, como vector
    #* y = Valores de y, como vector 
    #* h = Salto h 
    #* Y0 = Condición inicial
    '''
    YAnswers = np.zeros_like(X)
    YAnswers[0] = Y0

    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers[i])
            k2 = Fun((x + h), (YAnswers[i] + k1*h))
            YAnswers[i + 1] = YAnswers[i] + ((1/2)*k1 + (1/2)*k2)*h
    
    plt.plot(X,YAnswers, '.',label= 'Heun')
    
    return YAnswers

#Se sacan las soluciones mediante el método de Heun:
ResultadosHeun = Heun(Funcion, t, h, Y0)

def SolucionEDO(t):
    return (4/1.3)*(np.exp(0.8*t) - np.exp(-0.5*t)) + 2*np.exp(-0.5*t)

Y0 = 2
h = 0.5
x_range = [0.0, 4.0]
t =  np.arange(0, 4 + h, h)
RespuestasReales = SolucionEDO(t)

plt.plot(t, RespuestasReales, label="ref")
#Se define la solución de la EDO:
""""def SolucionEDO(T, y):
    '''
    Esta funcion expresa la Solución de la EDO
    '''
    YAnswers = np.zeros_like(T)
    YAnswers[0] = Y0
    for i, t in enumerate(T):
        if i+1 == len(T):
            break
        else:
            YAnswers[i + 1] = (4/1.3)*(np.exp(0.8*t) - np.exp(-0.5*t)) + 2*np.exp(-0.5*t)

    plt.plot(T, YAnswers, label= 'Solución')

    return YAnswers


#Se encuentra las soluciones en base a la solución real de la EDO:
RespuestasReales = SolucionEDO(t, YAnswers)"""
#print(f'Las respuestas reales son: {RespuestasReales}')
plt.legend()
plt.title('Prueba método RK2 propio')
plt.xlabel('Valores de t')
plt.ylabel('Valores estimados')
plt.show()

#Se define la función de error relativo para calcular los errores por valor:
def ErrorRelativo(RespuestasEstimadas, RespuestasReales):
    '''
    Esta función crea una tabla en formato .txt con las respuestas estimadas, las
    respuestas reales y el error relativo entre ambos, este esta calculado 
    como:
    Error relativo = abs((RespuestasEstimadas - RespuestasReales)/RespuestasReales)
    el orden de la tabla es por filas, de modo que el orden es:
    #*Respuestas estimadas
    #*Respuestas reales
    #*Error relativo
    '''
    AnswersMatriz = []
    AnswersMatriz.append(RespuestasEstimadas)
    AnswersMatriz.append(RespuestasReales)
    ErrorRelativo = []

    for i, RE in enumerate(RespuestasEstimadas):
        ErroresRelativos = abs((RE - RespuestasReales[i])/RespuestasReales[i])
        ErrorRelativo.append(ErroresRelativos)

    AnswersMatriz.append(ErrorRelativo)

    return AnswersMatriz

#Se saca el error relativo por prueba del método de RK2 propio
Matriz0= ErrorRelativo(RespuestasEstimadas0, RespuestasReales)
np.savetxt('MatrizPregunta3_0.txt', Matriz0, fmt='%f', delimiter='\t')
Matriz1 = ErrorRelativo(RespuestasEstimadas1, RespuestasReales)
np.savetxt('MatrizPregunta3_1.txt', Matriz1, fmt='%f', delimiter='\t')
Matriz2 = ErrorRelativo(RespuestasEstimadas2, RespuestasReales)
np.savetxt('MatrizPregunta3_2.txt', Matriz2, fmt='%f', delimiter='\t')
Matriz3 = ErrorRelativo(RespuestasEstimadas3, RespuestasReales)
np.savetxt('MatrizPregunta3_3.txt', Matriz3, fmt='%f', delimiter='\t')

#Se saca el error relativo para el método de Heun:
ResultadoHeun = ErrorRelativo(ResultadosHeun, RespuestasReales)
np.savetxt('MatrizPregunta3_4.txt', ResultadoHeun, fmt='%f', delimiter='\t')

#Se define una función para comparar los errores relativos de cada tabla creada:
def DiferenciasErroresRelativos(MatrizI, ResultadoHeun):
    '''
    Esta función toma la última lista de cada lista de listas proporcionada para
    sacar la diferencia entre errores relativos respecto a la solución real
    '''
    NuevoVector0 =MatrizI[-1] 
    NuevoVector1 =ResultadoHeun[-1]
    MatrizDiferencias = []

    for i, R in enumerate(NuevoVector0):
        Diferencia = R - NuevoVector1[i]
        MatrizDiferencias.append(Diferencia)

    return MatrizDiferencias

Error0 = DiferenciasErroresRelativos(Matriz0, ResultadoHeun)
np.savetxt('DiferenciaErroresRelativos0.txt', Error0, fmt='%f', delimiter='\t')
Error1 = DiferenciasErroresRelativos(Matriz1, ResultadoHeun)
np.savetxt('DiferenciaErroresRelativos1.txt', Error1, fmt='%f', delimiter='\t')
Error2 = DiferenciasErroresRelativos(Matriz2, ResultadoHeun)
np.savetxt('DiferenciaErroresRelativos2.txt', Error2, fmt='%f', delimiter='\t')
Error3 = DiferenciasErroresRelativos(Matriz3, ResultadoHeun)
np.savetxt('DiferenciaErroresRelativos3.txt', Error3, fmt='%f', delimiter='\t')

suma0 = sum(Error0)
print(suma0)
suma1 = sum(Error1)
print(suma1)
suma2 = sum(Error2)
print(suma2)
suma3 = sum(Error3)
print(suma3)
'''
#*Pregunta 4:
implementando RK adaptativo con reducción a la mitad para resolver la misma
EDO de la pregunta 3, compare los resultados (usando errores relativos)
con la solución analítica y la estimación obtenida 
'''
'''
Para responder la pregunta es necesario crear la función del metodo
adaptativo (RK4).
Este metodo sigue los siguientes pasos:
1.Usa un paso completo h para estimar la primera solución (Y1)
2.Usa dos pasos de h/2 para estimar la segunda solución (Y2)
3. se estima el error talque: error = Y2 - Y1

Para RK4 la correción es del estilo:
NuevoY2 = Y2 + (error/15)
'''

#Se define el metodo de Runge-Kutta de orden 4
def RK4(Fun, X, h, Y0):
    '''
    Esta funcion trabaja con el metodo de Euler, tal que:
    #* Fun = Función a evaluar
    #* x = Valores de x, como vector
    #* h = Salto h 
    #* Y0 = Condición inicial
    '''
    YAnswers = np.zeros_like(X) #*Se crea un vector donde poner los resultados
    YAnswers[0] = Y0 #*Se almacena la condicion inicial como el primer elemento del vector
    
    '''
    Mediante un ciclo for se itera la cantidad de elementos que tiene X
    de modo que crear las soluciones.
    Para evitar errores no se crea la última solucion, ya que esta sale 
    del tamaño del vector
    '''
    for i, x in enumerate(X):
        if i+1 == len(X):
            break
        else:
            k1 = Fun(x, YAnswers[i])
            k2 = Fun((x + (1/2)*h),(YAnswers[i] + (1/2)*k1*h))
            k3 = Fun((x + (1/2)*h),(YAnswers[i] + (1/2)*k2*h))
            k4 = Fun((x + h),(YAnswers[i] + k3*h))
            YAnswers[i + 1] = YAnswers[i] + (1/6)*(k1 + 2*k2 + 2*k3 + k4)*h
    
    plt.plot(X,YAnswers,label= 'RK4')
    
    return YAnswers
'''
En este caso se ocupa el método adaptativo para cada valor de t, de modo
de corregir cada solución Y1 con la solución Y2.
#? no entinendo eso de que se ocupan dos pasos de h/2 para Y2
'''

TT = np.arange(0, 4 + (h/2), (h/2))
def MetodoAdaptativo(RK4, Funcion, RK2Propio, t, h, Y0,TT):
    '''
    Esta función trabaja con el método adaptativo, donde se le entrega:
    #* RK4 = Método de Rongue-Kutta de orden 4
    #* Funcion = Funcion matemática a evaluar
    #* RK2Propio = Función propia de RK2
    #* t = Vector t con los valores a iterar 
    #* h = Salto h
    #* Y0 = Condición inicial
    '''

    YAnswer1 = []
    YAnswers2 = []
    NuevoY2 = []
        
    Y1 = RK4(Funcion, t, h, Y0)
    Y2 = RK4(Funcion, TT, (h/2), Y0)
    for i, T in enumerate(t):
        YAnswer1.append(Y1[i])
        YAnswers2.append(Y2[i])

        #Correción por punto:
        error = YAnswers2[i] - YAnswer1[i]
        Correccion = YAnswers2[i] - (error/15)
        NuevoY2.append(Correccion)

    Matriz = []

    Matriz.append(YAnswer1)
    Matriz.append(YAnswers2)
    Matriz.append(NuevoY2)

    np.savetxt('MatrizMetodoAdaptativo11111.txt', Matriz, fmt='%f', delimiter='\t')

    return Matriz

a = MetodoAdaptativo(RK4, Funcion, RK2propio0, t, h, Y0, TT)
ErrorVector1 = ErrorRelativo(a[0], RespuestasReales)
np.savetxt('ErroresMetodoAdaptativo0.txt', ErrorVector1, fmt='%f', delimiter='\t')
ErrorVector2 = ErrorRelativo(a[2], RespuestasReales)
np.savetxt('ErroresMetodoAdaptativo1.txt', ErrorVector2, fmt='%f', delimiter='\t')

SumaError1 = sum(ErrorVector1[2])
print(SumaError1)

SumaError2 = sum(ErrorVector2[2])
print(SumaError2)