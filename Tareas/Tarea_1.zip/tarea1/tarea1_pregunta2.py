import numpy as np
import matplotlib.pyplot as plt

#pregunta 2 

# Función 1/(1 + x)
def derivada_ln(x1, N):
    sumatoria_derivada = 0
    for n in range(1, (1+ N)):
        sumatoria_derivada += (-1) ** (n - 1) * (x1 ** (n-1))*n
    return sumatoria_derivada

# Valores de N
valores_N = range(1, 11)

# Valores de x para graficar (excluyendo -1 para evitar el warning)
valores_x1 = np.linspace(-0.99, 1, 100)

# Resultados de las aproximaciones para cada N y x
resultados1 = np.zeros((len(valores_N), len(valores_x1)))

# Calcular las aproximaciones
for i, N in enumerate(valores_N):
    resultados1[i] = derivada_ln(valores_x1, N)

# Función 1/(1 + x) para referencia
valores_ideales1 = (1 / (1 + valores_x1))

# Graficar las aproximaciones y la función de referencia
plt.figure(figsize=(10, 6))
for i, N in enumerate(valores_N):
    if N in [2, 4, 6, 8, 10]:
        plt.plot(valores_x1, resultados1[i], label=f'Aproximación N={N}', linestyle='--')

plt.plot(valores_x1, valores_ideales1, label='d/dx (ln(1 + x))', color='black', linewidth=2)
plt.xlabel('valores de x')
plt.ylabel('Aproximaciones')
plt.title('Aproximaciones de la serie de Taylor para la derivada de  ln(1 + x)')
plt.legend()
plt.grid(True)
plt.show()

# Calcular el error relativo absoluto para x = 0.25 y cada N
x1 = 0.25
valor_real1 = (1/(1 + x1))


for N in valores_N:
    r_serie1 = derivada_ln(x1, N)
    # errores = error_rabsoluto(valor, r_serie1(x, N))
    error1 = np.abs((valor_real1 - r_serie1)/valor_real1)
    print(error1)
