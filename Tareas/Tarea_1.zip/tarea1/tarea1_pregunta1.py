import numpy as np
import matplotlib.pyplot as plt

#Pregunta 1
 
# Función ln(1 + x)
def serie_ln(x, N):
    sumatoria_ln = 0
    for n in range(1, N + 1):
        sumatoria_ln += (-1) ** (n - 1) * (x ** n) / n
    return sumatoria_ln

# Valores de N
valores_N = range(1, 11)

# Valores de x para graficar (excluyendo -1 para evitar el warning)
valores_x = np.linspace(-0.99, 1, 100)

# Resultados de las aproximaciones para cada N y x
resultados = np.zeros((len(valores_N), len(valores_x)))

# Calcular las aproximaciones
for i, N in enumerate(valores_N):
    resultados[i] = serie_ln(valores_x, N)

# Función ln(1 + x) para referencia
valores_ideales = np.log(1 + valores_x)

# Graficar las aproximaciones y la función de referencia
plt.figure(figsize=(10, 6))
for i, N in enumerate(valores_N):
    if N in [2, 4, 6, 8,10]:
        plt.plot(valores_x, resultados[i], label=f'Aproximación N={N}', linestyle='--')

plt.plot(valores_x, valores_ideales, label='ln(1 + x)', color='black', linewidth=2)
plt.xlabel('valores de x')
plt.ylabel('Aproximaciones')
plt.title('Aproximaciones de la serie de Taylor para ln(1 + x)')
plt.legend()
plt.grid(True)
plt.show()

# Calcular el error relativo absoluto para x = 0.25 y cada N
x = 0.25
valor_real = np.log(1 + x)


for N in valores_N:
    r_serie = serie_ln(x, N)
    # errores = error_rabsoluto(valor, serie_ln(x, N))
    error = np.abs((valor_real - r_serie)/valor_real)
    print(error)
